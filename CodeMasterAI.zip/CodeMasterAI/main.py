import logging
from telegram.ext import ApplicationBuilder, CommandHandler, MessageHandler, filters
from config import TELEGRAM_TOKEN, GEMINI_API_KEY, DB_PATH, LOG_FILE

from bot.db.database import Database
from bot.core.user_manager import UserManager
from bot.core.lesson_manager import LessonManager
from bot.core.error_analyzer import ErrorAnalyzer
from bot.core.ai_layer import GeminiAI
from bot.handlers.command_handlers import Handlers

# إعداد السجلات (Logging)
logging.basicConfig(
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    level=logging.INFO,
    filename=LOG_FILE
)
logger = logging.getLogger(__name__)

def main():
    # تهيئة المكونات
    db = Database(DB_PATH)
    user_manager = UserManager(db)
    lesson_manager = LessonManager()
    error_analyzer = ErrorAnalyzer()
    ai = GeminiAI(GEMINI_API_KEY)
    
    handlers = Handlers(user_manager, lesson_manager, error_analyzer, ai)

    # بناء التطبيق
    application = ApplicationBuilder().token(TELEGRAM_TOKEN).build()

    # إضافة المعالجات
    application.add_handler(CommandHandler("start", handlers.start))
    application.add_handler(CommandHandler("help", handlers.help_command))
    application.add_handler(CommandHandler("profile", handlers.profile))
    application.add_handler(CommandHandler("learn", handlers.learn))
    application.add_handler(CommandHandler("lesson", handlers.lesson))
    application.add_handler(CommandHandler("error", handlers.error_handler))
    application.add_handler(CommandHandler("leaderboard", handlers.leaderboard))
    
    # معالجة الرسائل النصية (لتحليل الكود)
    application.add_handler(MessageHandler(filters.TEXT & (~filters.COMMAND), handlers.handle_message))

    print("CodeMaster AI Bot is running...")
    application.run_polling()

if __name__ == '__main__':
    try:
        main()
    except Exception as e:
        logger.error(f"Critical error: {e}")
        print(f"حدث خطأ فادح: {e}")
