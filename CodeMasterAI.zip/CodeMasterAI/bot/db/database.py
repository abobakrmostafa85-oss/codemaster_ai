import sqlite3
import os
from datetime import datetime

class Database:
    def __init__(self, db_path="codemaster.db"):
        self.db_path = db_path
        self.init_db()

    def get_connection(self):
        return sqlite3.connect(self.db_path)

    def init_db(self):
        with self.get_connection() as conn:
            cursor = conn.cursor()
            
            # جدول المستخدمين
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS users (
                    user_id INTEGER PRIMARY KEY,
                    username TEXT,
                    full_name TEXT,
                    xp INTEGER DEFAULT 0,
                    level INTEGER DEFAULT 1,
                    joined_at TEXT,
                    streak INTEGER DEFAULT 0,
                    last_active TEXT,
                    completed_lessons INTEGER DEFAULT 0,
                    completed_challenges INTEGER DEFAULT 0,
                    fixed_errors INTEGER DEFAULT 0
                )
            ''')
            
            # جدول الإنجازات
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS achievements (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    user_id INTEGER,
                    achievement_name TEXT,
                    unlocked_at TEXT,
                    FOREIGN KEY (user_id) REFERENCES users (user_id)
                )
            ''')
            
            # جدول سجل الأخطاء
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS error_logs (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    user_id INTEGER,
                    error_type TEXT,
                    error_message TEXT,
                    timestamp TEXT,
                    FOREIGN KEY (user_id) REFERENCES users (user_id)
                )
            ''')
            
            # جدول التقدم في الدروس
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS user_progress (
                    user_id INTEGER,
                    topic TEXT,
                    level TEXT,
                    status TEXT, -- 'started', 'completed'
                    score INTEGER,
                    PRIMARY KEY (user_id, topic, level)
                )
            ''')
            
            conn.commit()

    def get_user(self, user_id):
        with self.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM users WHERE user_id = ?", (user_id,))
            return cursor.fetchone()

    def add_user(self, user_id, username, full_name):
        if not self.get_user(user_id):
            with self.get_connection() as conn:
                cursor = conn.cursor()
                cursor.execute(
                    "INSERT INTO users (user_id, username, full_name, joined_at, last_active) VALUES (?, ?, ?, ?, ?)",
                    (user_id, username, full_name, datetime.now().isoformat(), datetime.now().isoformat())
                )
                conn.commit()

    def update_xp(self, user_id, xp_gain):
        with self.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("UPDATE users SET xp = xp + ? WHERE user_id = ?", (xp_gain, user_id))
            
            # تحديث المستوى تلقائياً (كل 100 XP مستوى)
            cursor.execute("SELECT xp FROM users WHERE user_id = ?", (user_id,))
            current_xp = cursor.fetchone()[0]
            new_level = (current_xp // 100) + 1
            cursor.execute("UPDATE users SET level = ? WHERE user_id = ?", (new_level, user_id))
            conn.commit()
            return new_level

    def add_achievement(self, user_id, achievement_name):
        with self.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT 1 FROM achievements WHERE user_id = ? AND achievement_name = ?", (user_id, achievement_name))
            if not cursor.fetchone():
                cursor.execute(
                    "INSERT INTO achievements (user_id, achievement_name, unlocked_at) VALUES (?, ?, ?)",
                    (user_id, achievement_name, datetime.now().isoformat())
                )
                conn.commit()
                return True
        return False

    def log_error(self, user_id, error_type, error_message):
        with self.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute(
                "INSERT INTO error_logs (user_id, error_type, error_message, timestamp) VALUES (?, ?, ?, ?)",
                (user_id, error_type, error_message, datetime.now().isoformat())
            )
            cursor.execute("UPDATE users SET fixed_errors = fixed_errors + 1 WHERE user_id = ?", (user_id,))
            conn.commit()

    def get_leaderboard(self, limit=10):
        with self.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT username, full_name, xp, level FROM users ORDER BY xp DESC LIMIT ?", (limit,))
            return cursor.fetchall()
