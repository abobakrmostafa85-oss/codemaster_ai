from telegram import Update, ReplyKeyboardMarkup
from telegram.ext import ContextTypes
from bot.core.user_manager import UserManager
from bot.core.lesson_manager import LessonManager
from bot.core.error_analyzer import ErrorAnalyzer
from bot.core.ai_layer import GeminiAI

class Handlers:
    def __init__(self, user_manager: UserManager, lesson_manager: LessonManager, error_analyzer: ErrorAnalyzer, ai: GeminiAI):
        self.user_manager = user_manager
        self.lesson_manager = lesson_manager
        self.error_analyzer = error_analyzer
        self.ai = ai

    async def start(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        user = update.effective_user
        self.user_manager.register_user(user)
        
        welcome_text = (
            f"مرحباً بك {user.first_name} في CodeMaster AI! 🤖\n\n"
            "أنا مدربك الشخصي لتعلم البرمجة بلغة Python ومحلل الأخطاء الذكي.\n\n"
            "استخدم القائمة أدناه أو الأوامر لبدء رحلتك:"
        )
        
        keyboard = [
            ['/learn 📚', '/profile 👤'],
            ['/challenge 🏆', '/daily 📅'],
            ['/help ❓', '/leaderboard 📊']
        ]
        reply_markup = ReplyKeyboardMarkup(keyboard, resize_keyboard=True)
        
        await update.message.reply_text(welcome_text, reply_markup=reply_markup)

    async def help_command(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        help_text = (
            "الأوامر المتاحة:\n"
            "/start - بدء البوت\n"
            "/learn - اختيار موضوع للتعلم\n"
            "/profile - عرض ملفك الشخصي وإحصائياتك\n"
            "/challenge - الحصول على تحدي برمجي\n"
            "/daily - المهمة اليومية\n"
            "/leaderboard - لوحة الصدارة\n"
            "/error - تحليل خطأ برمجي (أرسل الخطأ بعد الأمر)\n\n"
            "يمكنك أيضاً إرسال كود بايثون مباشرة وسأقوم بتحليله لك!"
        )
        await update.message.reply_text(help_text)

    async def profile(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        user_id = update.effective_user.id
        profile = self.user_manager.get_profile(user_id)
        
        if not profile:
            await update.message.reply_text("لم يتم العثور على ملفك الشخصي. أرسل /start أولاً.")
            return

        stats_text = (
            f"👤 ملف المستخدم: {profile['full_name']}\n"
            f"🏆 المستوى: {profile['level']}\n"
            f"✨ XP: {profile['xp']}\n"
            f"📚 الدروس المكتملة: {profile['completed_lessons']}\n"
            f"🎯 التحديات المنجزة: {profile['completed_challenges']}\n"
            f"🛠 الأخطاء المصححة: {profile['fixed_errors']}\n"
            f"🔥 الأيام المتتالية: {profile['streak']}"
        )
        await update.message.reply_text(stats_text)

    async def learn(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        topics = self.lesson_manager.get_topics()
        topics_text = "اختر موضوعاً للتعلم:\n" + "\n".join([f"- {t}" for t in topics])
        await update.message.reply_text(topics_text + "\n\nمثال: استخدم /lesson Variables Beginner")

    async def lesson(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        if len(context.args) < 2:
            await update.message.reply_text("يرجى استخدام الصيغة: /lesson [الموضوع] [المستوى]\nمثال: /lesson Variables Beginner")
            return
        
        topic, level = context.args[0], context.args[1]
        lesson = self.lesson_manager.get_lesson(topic, level)
        
        if lesson:
            response = (
                f"📖 {lesson['title']}\n\n"
                f"{lesson['content']}\n\n"
                f"💻 مثال:\n`{lesson['example']}`\n\n"
                f"📝 تمرين:\n{lesson['exercise']}\n\n"
                "أرسل حلك للكود وسأقوم بتقييمه!"
            )
            await update.message.reply_text(response, parse_mode='Markdown')
        else:
            await update.message.reply_text("عذراً، هذا الدرس غير متوفر حالياً.")

    async def error_handler(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        error_text = " ".join(context.args)
        if not error_text:
            await update.message.reply_text("يرجى إرسال نص الخطأ بعد أمر /error")
            return

        if self.ai.is_available():
            analysis = self.ai.analyze_error_deeply(error_text)
            await update.message.reply_text(f"🔍 تحليل الذكاء الاصطناعي:\n\n{analysis}")
        else:
            analysis = self.error_analyzer.analyze_traceback(error_text)
            response = (
                f"🔍 نوع الخطأ: {analysis['type']}\n"
                f"💡 السبب: {analysis['reason']}\n\n"
                f"❌ مثال خاطئ:\n`{analysis['bad']}`\n\n"
                f"✅ مثال صحيح:\n`{analysis['good']}`\n\n"
                f"📌 نصيحة: {analysis['tips']}"
            )
            await update.message.reply_text(response, parse_mode='Markdown')
        
        self.user_manager.db.log_error(update.effective_user.id, "Traceback", error_text[:100])

    async def leaderboard(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        top_users = self.user_manager.db.get_leaderboard()
        leaderboard_text = "📊 لوحة الصدارة (أفضل 10):\n\n"
        for i, user in enumerate(top_users, 1):
            leaderboard_text += f"{i}. {user[1]} - Level {user[3]} ({user[2]} XP)\n"
        await update.message.reply_text(leaderboard_text)

    async def handle_message(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        code = update.message.text
        # إذا كان النص يبدو ككود برمجي
        if "(" in code or "=" in code or "print" in code:
            report, score = self.error_analyzer.analyze_code(code)
            await update.message.reply_text(report)
            if score == 100:
                self.user_manager.award_xp(update.effective_user.id, 10)
                await update.message.reply_text("رائع! حصلت على 10 XP.")
        else:
            await update.message.reply_text("أرسل أمراً أو كود بايثون للتحليل. استخدم /help لرؤية الأوامر.")
