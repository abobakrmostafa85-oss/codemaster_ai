LESSONS = {
    "Variables": {
        "Beginner": {
            "title": "المتغيرات (Variables)",
            "content": "المتغير هو مكان في الذاكرة لتخزين البيانات. في Python، لا نحتاج لتحديد نوع المتغير مسبقاً.",
            "example": "x = 5\nname = 'CodeMaster'",
            "exercise": "قم بإنشاء متغير باسم age وقيمته 25",
            "solution": "age = 25"
        },
        "Intermediate": {
            "title": "المتغيرات المتقدمة",
            "content": "يمكننا تعيين قيم متعددة لمتغيرات متعددة في سطر واحد.",
            "example": "x, y, z = 1, 2, 3",
            "exercise": "قم بتعيين القيمة 10 لـ a و 20 لـ b في سطر واحد",
            "solution": "a, b = 10, 20"
        }
    },
    "Loops": {
        "Beginner": {
            "title": "الحلقات التكرارية (Loops)",
            "content": "تستخدم for لتكرار كود معين لعدد محدد من المرات أو عبر عناصر قائمة.",
            "example": "for i in range(5):\n    print(i)",
            "exercise": "اكتب حلقة تطبع الأرقام من 0 إلى 2",
            "solution": "for i in range(3):\n    print(i)"
        }
    }
}

CHALLENGES = [
    {
        "id": 1,
        "title": "تحدي الجمع",
        "description": "اكتب برنامجاً يجمع رقمين x و y ويطبع الناتج.",
        "difficulty": "Easy",
        "xp": 20
    },
    {
        "id": 2,
        "title": "تحدي القوائم",
        "description": "أنشئ قائمة تحتوي على 3 ألوان واطبع اللون الثاني.",
        "difficulty": "Medium",
        "xp": 40
    }
]

DAILY_TASKS = [
    "قم بكتابة دالة تحسب مساحة المربع.",
    "اشرح الفرق بين List و Tuple في سطر واحد.",
    "استخدم دالة input لاستقبال اسم المستخدم."
]
