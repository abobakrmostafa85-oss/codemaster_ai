from bot.db.database import Database

class UserManager:
    def __init__(self, db: Database):
        self.db = db

    def register_user(self, user):
        self.db.add_user(user.id, user.username, user.full_name)

    def get_profile(self, user_id):
        user_data = self.db.get_user(user_id)
        if not user_data:
            return None
        
        # تحويل البيانات إلى قاموس لسهولة التعامل
        profile = {
            "id": user_data[0],
            "username": user_data[1],
            "full_name": user_data[2],
            "xp": user_data[3],
            "level": user_data[4],
            "joined_at": user_data[5],
            "streak": user_data[6],
            "completed_lessons": user_data[8],
            "completed_challenges": user_data[9],
            "fixed_errors": user_data[10]
        }
        return profile

    def award_xp(self, user_id, amount, reason=""):
        new_level = self.db.update_xp(user_id, amount)
        # هنا يمكن إضافة منطق للتحقق من الإنجازات بناءً على XP
        self.check_achievements(user_id)
        return new_level

    def check_achievements(self, user_id):
        profile = self.get_profile(user_id)
        unlocked = []
        
        # أمثلة على الإنجازات
        if profile["completed_lessons"] >= 1:
            if self.db.add_achievement(user_id, "أول تمرين"): unlocked.append("أول تمرين")
        
        if profile["completed_lessons"] >= 10:
            if self.db.add_achievement(user_id, "أول 10 تمارين"): unlocked.append("أول 10 تمارين")
            
        if profile["fixed_errors"] >= 5:
            if self.db.add_achievement(user_id, "مكتشف الأخطاء"): unlocked.append("مكتشف الأخطاء")
            
        return unlocked
