from bot.data.lessons import LESSONS, CHALLENGES, DAILY_TASKS
import random

class LessonManager:
    def __init__(self):
        self.lessons = LESSONS
        self.challenges = CHALLENGES
        self.daily_tasks = DAILY_TASKS

    def get_topics(self):
        return list(self.lessons.keys())

    def get_lesson(self, topic, level):
        if topic in self.lessons and level in self.lessons[topic]:
            return self.lessons[topic][level]
        return None

    def get_random_challenge(self):
        return random.choice(self.challenges)

    def get_daily_task(self):
        return random.choice(self.daily_tasks)

    def check_exercise_solution(self, topic, level, user_solution):
        lesson = self.get_lesson(topic, level)
        if not lesson:
            return False
        
        # تنظيف الحل من المسافات الزائدة للمقارنة البسيطة
        # في نظام حقيقي قد نستخدم exec() مع حماية، لكن هنا سنعتمد المقارنة النصية
        clean_user = user_solution.strip().replace(" ", "")
        clean_solution = lesson["solution"].strip().replace(" ", "")
        
        return clean_user == clean_solution
