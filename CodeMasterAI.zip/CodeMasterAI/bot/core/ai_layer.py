import requests
import json

class GeminiAI:
    def __init__(self, api_key=None):
        self.api_key = api_key
        self.api_url = f"https://generativelanguage.googleapis.com/v1beta/models/gemini-pro:generateContent?key={self.api_key}"

    def is_available(self):
        return self.api_key is not None and len(self.api_key) > 10

    def generate_response(self, prompt):
        if not self.is_available():
            return None
        
        headers = {'Content-Type': 'application/json'}
        data = {
            "contents": [{
                "parts": [{"text": prompt}]
            }]
        }
        
        try:
            response = requests.post(self.api_url, headers=headers, data=json.dumps(data))
            if response.status_code == 200:
                result = response.json()
                return result['candidates'][0]['content']['parts'][0]['text']
            return f"Error: {response.status_code}"
        except Exception as e:
            return f"Exception: {str(e)}"

    def analyze_error_deeply(self, error_text):
        prompt = f"حلل خطأ البرمجة التالي في لغة بايثون واشرحه باللغة العربية بأسلوب تعليمي مع مثال صحيح:\n{error_text}"
        return self.generate_response(prompt)

    def generate_new_challenge(self, topic):
        prompt = f"أنشئ تحدي برمجي جديد في بايثون حول موضوع {topic}. التحدي يجب أن يكون باللغة العربية ويتضمن الوصف والمخرجات المتوقعة."
        return self.generate_response(prompt)
