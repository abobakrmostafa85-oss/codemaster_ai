import re

class ErrorAnalyzer:
    def __init__(self):
        self.error_patterns = {
            "SyntaxError": {
                "reason": "هناك خطأ في قواعد كتابة الكود، مثل نسيان نقطتين (:) أو قوس.",
                "example_bad": "if True\n    print('Hello')",
                "example_good": "if True:\n    print('Hello')",
                "tips": "تأكد دائماً من إغلاق الأقواس ووضع النقطتين بعد if, for, while, def."
            },
            "NameError": {
                "reason": "تحاول استخدام متغير أو دالة غير معرفة.",
                "example_bad": "print(x) # x is not defined",
                "example_good": "x = 10\nprint(x)",
                "tips": "تأكد من كتابة اسم المتغير بشكل صحيح ومن تعريفه قبل استخدامه."
            },
            "IndexError": {
                "reason": "تحاول الوصول إلى عنصر في قائمة باستخدام فهرس (index) غير موجود.",
                "example_bad": "my_list = [1, 2]\nprint(my_list[5])",
                "example_good": "my_list = [1, 2]\nprint(my_list[1])",
                "tips": "تذكر أن الفهرس يبدأ من 0 وينتهي عند (طول القائمة - 1)."
            },
            "KeyError": {
                "reason": "تحاول الوصول إلى مفتاح (key) غير موجود في القاموس (dictionary).",
                "example_bad": "my_dict = {'a': 1}\nprint(my_dict['b'])",
                "example_good": "print(my_dict.get('b', 'Not Found'))",
                "tips": "استخدم دالة .get() لتجنب هذا الخطأ عند عدم التأكد من وجود المفتاح."
            },
            "TypeError": {
                "reason": "تحاول إجراء عملية على أنواع بيانات غير متوافقة.",
                "example_bad": "print('Age: ' + 25)",
                "example_good": "print('Age: ' + str(25))",
                "tips": "تأكد من تحويل أنواع البيانات باستخدام str(), int(), float() عند الحاجة."
            }
        }

    def analyze_traceback(self, traceback_text):
        for error_type in self.error_patterns:
            if error_type in traceback_text:
                analysis = self.error_patterns[error_type]
                return {
                    "type": error_type,
                    "reason": analysis["reason"],
                    "bad": analysis["example_bad"],
                    "good": analysis["example_good"],
                    "tips": analysis["tips"]
                }
        
        return {
            "type": "خطأ غير معروف",
            "reason": "لم أتمكن من تحديد السبب بدقة من خلال النظام المحلي.",
            "bad": "N/A",
            "good": "N/A",
            "tips": "حاول إرسال الكود بالكامل أو استخدم Gemini AI لتحليل أعمق."
        }

    def analyze_code(self, code):
        # تحليل بسيط للكود لاكتشاف الأخطاء الشائعة
        issues = []
        score = 100
        
        if "print " in code:
            issues.append("في Python 3، يجب استخدام الأقواس مع print(). مثال: print('hello')")
            score -= 20
        
        if re.search(r"if.*[^:]\n", code):
            issues.append("نسيت وضع النقطتين (:) بعد جملة if.")
            score -= 15

        if len(issues) == 0:
            return "الكود يبدو نظيفاً! تقييم: 100/100", 100
        
        report = "تقرير تحليل الكود:\n" + "\n".join([f"- {i}" for i in issues])
        return report, max(0, score)
