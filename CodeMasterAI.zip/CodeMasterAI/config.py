import os
from dotenv import load_dotenv

load_dotenv()

# إعدادات البوت
TELEGRAM_TOKEN = os.getenv("TELEGRAM_TOKEN", "YOUR_BOT_TOKEN_HERE")
GEMINI_API_KEY = os.getenv("GEMINI_API_KEY", None)

# إعدادات قاعدة البيانات
DB_PATH = "codemaster.db"

# إعدادات النظام
LOG_FILE = "bot_logs.log"
DEBUG = True
